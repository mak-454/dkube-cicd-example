"""Top-level package for DKube CICD Controller."""

__author__ = """One Convergence"""
__email__ = "dkube@oneconvergence.com"
__version__ = "1.6.0"
